1. Name: Duncan Law

2. Company: none

3. Billing address: 10 Ring Terrace, Inchicore, Dublin 8, Ireland.

4. Shipping address: 10 Ring Terrace, Inchicore, Dublin 8, Ireland.

5. Shipping option: AIRMAIL EUROPE.

6. Order: DSS. 1 piece
   
7. Not VAT registered.

8. Payment option: Mastercard.

9. De-panelization: 
Rough. (Guillotine.) 
Please fill panel with multiple copies of my PCB.
single PCB = 49.5 x 49.5mm.
There should be space for 6 of my PCBs on 1 DSS panel.

10. Notes: This is my first order so apologies if there are any problems with my problems with my Gerber files.

mrdunk@gmail.com

