Requires Python, pySerial and pyGame to run.

http://python.org/
http://pyserial.sourceforge.net
http://www.pygame.org

Install those then run "dial.py test" to run in test mode. (The artificial horizon should follow the mouse.)
