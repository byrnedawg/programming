MMA8452 Firmware
================

These are example Arduino sketches for interfacing with the MMA8452 Accelerometer breakout. You will need Arduino 1.0+ to run them. 

* MMA8452_BasicExample shows how to read the X/Y/Z accelerations and basic functions of the accelerometer.
* MMA8452_AdvancedExample shows how to use most features of the accelerometer, including single/double tap readings. 