The contents of these directories depend upon
avr-gcc 2.97 or greater from  http://www.avrfreaks.net

Follow the instructions for installing and testing the
compiler.

Then, add to your AUTOEXEC.BAT or your environment
(winXP or *nix), the following line:

set AVRX=C:\The\Absolute\Path  (make suitable changes for *nix)

to the directory where *THIS* file is found.

Change into the various directories and execute "make"
to build the respective applications and libraries.

AvrX		- The RTOS library
Examples	- Well, Examples, yes!
TestCases	- In case you want to hack the kernel